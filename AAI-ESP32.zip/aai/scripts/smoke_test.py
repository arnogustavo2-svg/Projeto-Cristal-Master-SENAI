import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Modo dev explícito: sem token configurado, aceita eventos.
os.environ.setdefault("ESP32_DEV_MODE", "true")

import app as modulo
import database as db


def main():
    with tempfile.TemporaryDirectory() as pasta:
        db.CAMINHO_DO_BANCO = Path(pasta) / "teste.db"
        db.inicializar_banco()
        cliente = modulo.app.test_client()

        # Telas
        assert cliente.get("/").status_code == 200
        assert cliente.get("/lider").status_code == 200
        assert cliente.get("/lider/materiais").status_code == 200
        assert cliente.get("/lider/estoque").status_code == 200
        assert cliente.get("/lider/operadores").status_code == 200
        assert cliente.get("/lider/ordens").status_code == 200
        assert cliente.get("/lider/tarefas").status_code == 200
        assert cliente.get("/lider/movimentacoes").status_code == 200
        assert cliente.get("/lider/auditoria").status_code == 200
        assert cliente.get("/lider/dispositivos").status_code == 200
        assert cliente.get("/lider/rfid").status_code == 200
        assert cliente.get("/lider/excecoes").status_code == 200
        assert cliente.get("/operador").status_code == 200
        assert cliente.get("/operador/inicio").status_code == 200
        assert cliente.get("/operador/tarefas").status_code == 200
        assert cliente.get("/operador/confirmacao").status_code == 200
        assert cliente.get("/operador/excecao").status_code == 200
        assert cliente.get("/api/health").get_json()["status"] == "ok"

        # Materiais
        r = cliente.post("/api/materiais", json={"codigo": "MAT-001", "descricao": "Resina", "unidade": "kg"})
        assert r.status_code == 201, r.get_json()
        r = cliente.post("/api/materiais", json={"codigo": "MAT-001", "descricao": "Duplicado", "unidade": "kg"})
        assert r.status_code == 409, r.get_json()
        r = cliente.post("/api/materiais", json={"codigo": "", "descricao": "", "unidade": ""})
        assert r.status_code == 422
        assert cliente.get("/api/materiais").get_json()[0]["codigo"] == "MAT-001"
        material_id = cliente.get("/api/materiais").get_json()[0]["id"]

        assert cliente.post("/api/materiais/9999/desativar").status_code == 404
        assert cliente.post(f"/api/materiais/{material_id}/desativar").status_code == 200
        assert cliente.post(f"/api/materiais/{material_id}/ativar").status_code == 200

        # Operadores
        r = cliente.post("/api/operadores", json={"matricula": "OP-001", "nome": "Operador de teste"})
        assert r.status_code == 201, r.get_json()
        assert cliente.post("/api/operador/identificar", json={"matricula": "OP-001"}).status_code == 200
        assert cliente.post("/api/operador/identificar", json={"matricula": "XX-999"}).status_code == 404

        # Posições / lotes / pallets
        r = cliente.post("/api/posicoes", json={"codigo": "POS-A1"})
        assert r.status_code == 201, r.get_json()
        posicao_id = r.get_json()["id"]
        r = cliente.post("/api/lotes", json={"material_id": material_id, "codigo": "LOTE-001"})
        assert r.status_code == 201, r.get_json()
        lote_id = r.get_json()["id"]
        r = cliente.post("/api/lotes", json={"material_id": 9999, "codigo": "LOTE-X"})
        assert r.status_code == 404, r.get_json()
        r = cliente.post("/api/pallets", json={"lote_id": lote_id, "codigo": "PLT-001", "posicao_id": posicao_id})
        assert r.status_code == 201, r.get_json()
        pallet_id = r.get_json()["id"]

        # RFID: cadastro, duplicidade, consulta
        r = cliente.post("/api/rfid", json={
            "uid": "04-a7-32-91-b2-6c-80",
            "material_id": material_id,
            "lote_id": lote_id,
            "pallet_id": pallet_id,
            "posicao_id": posicao_id,
            "quantidade": 25,
        })
        assert r.status_code == 201, r.get_json()
        assert r.get_json()["uid"] == "04-A7-32-91-B2-6C-80"
        r = cliente.post("/api/rfid", json={
            "uid": "04A73291B26C80", "material_id": material_id,
        })
        assert r.status_code == 409, r.get_json()
        assert cliente.get("/api/rfid/04-A7-32-91-B2-6C-80").status_code == 200
        assert cliente.get("/api/rfid/04A73291B26C80").status_code == 200
        assert cliente.get("/api/rfid/DEADBEEF").status_code == 404

        # Evento de dispositivo + idempotência + contexto da UID
        evento = {"evento_id": "EVT-001", "dispositivo_id": "ESP32-A1",
                  "uid_rfid": "04-A7-32-91-B2-6C-80", "tipo_evento": "tag_detectada",
                  "valor": True}
        r = cliente.post("/api/dispositivos/eventos", json=evento)
        assert r.status_code == 201, r.get_json()
        assert r.get_json()["uid_rfid"] == "04-A7-32-91-B2-6C-80"
        assert r.get_json()["contexto"]["material_codigo"] == "MAT-001"

        r = cliente.post("/api/dispositivos/eventos", json=evento)
        assert r.status_code == 200, r.get_json()
        assert r.get_json()["status"] == "duplicado"

        assert db.calcular_saldo(material_id=material_id) == 0

        # Estoque: entrada vinculada ao lote/pallet
        r = cliente.post("/api/movimentacoes/entrada",
                         json={"material_id": material_id, "lote_id": lote_id, "pallet_id": pallet_id,
                               "posicao_id": posicao_id, "quantidade": 100})
        assert r.status_code == 201, r.get_json()
        assert db.calcular_saldo(material_id=material_id) == 100
        assert db.calcular_saldo(pallet_id=pallet_id) == 100

        # Bloqueio de pallet
        assert cliente.post(f"/api/pallets/{pallet_id}/bloquear", json={"bloqueado": True}).status_code == 200
        assert cliente.get("/api/estoque").get_json()["itens_bloqueados"][0]["codigo"] == "PLT-001"

        # OP + tarefas
        r = cliente.post("/api/ordens", json={
            "codigo": "OP-100", "produto": "Produto A", "prioridade": 2,
            "itens": [{"material_id": material_id, "quantidade": 10}],
        })
        assert r.status_code == 201, r.get_json()
        op_id = r.get_json()["id"]
        assert cliente.get(f"/lider/ordens/{op_id}").status_code == 200
        assert cliente.get("/lider/ordens/999999").status_code == 404
        r = cliente.post(f"/api/ordens/{op_id}/gerar-tarefas", json={})
        assert r.status_code == 201, r.get_json()
        tarefas = cliente.get("/api/tarefas").get_json()
        assert len(tarefas) == 1
        tarefa_id = tarefas[0]["id"]
        assert cliente.get(f"/operador/tarefas/{tarefa_id}").status_code == 200

        # Pallet bloqueado impede conclusão
        assert cliente.post(f"/api/operador/tarefas/{tarefa_id}/iniciar",
                            json={"matricula": "OP-001"}).status_code == 200
        r = cliente.post(f"/api/operador/tarefas/{tarefa_id}/concluir",
                         json={"matricula": "OP-001", "quantidade_retirada": 5, "pallet_id": pallet_id})
        assert r.status_code == 409, r.get_json()

        # Desbloqueia e conclui
        assert cliente.post(f"/api/pallets/{pallet_id}/desbloquear").status_code == 200
        r = cliente.post(f"/api/operador/tarefas/{tarefa_id}/concluir",
                         json={"matricula": "OP-001", "quantidade_retirada": 10, "pallet_id": pallet_id})
        assert r.status_code == 200, r.get_json()
        assert db.calcular_saldo(material_id=material_id) == 90
        assert db.calcular_saldo(pallet_id=pallet_id) == 90

        assert cliente.get(f"/api/ordens/{op_id}").get_json()["status"] == "finalizada"

        # Saldo insuficiente rejeitado
        r2 = cliente.post("/api/ordens", json={
            "codigo": "OP-101", "produto": "Produto B", "prioridade": 1,
            "itens": [{"material_id": material_id, "quantidade": 500}],
        })
        op2_id = r2.get_json()["id"]
        cliente.post(f"/api/ordens/{op2_id}/gerar-tarefas", json={})
        tarefa2_id = [t for t in cliente.get("/api/tarefas").get_json() if t["op_id"] == op2_id][0]["id"]
        cliente.post(f"/api/operador/tarefas/{tarefa2_id}/iniciar", json={"matricula": "OP-001"})
        r = cliente.post(f"/api/operador/tarefas/{tarefa2_id}/concluir",
                         json={"matricula": "OP-001", "quantidade_retirada": 500, "pallet_id": pallet_id})
        assert r.status_code == 409, r.get_json()

        # Exceção
        r = cliente.post("/api/excecoes", json={
            "matricula": "OP-001", "motivo": "pallet_nao_encontrado",
            "observacao": "Teste",
        })
        assert r.status_code == 201, r.get_json()
        excecao_id = r.get_json()["id"]
        assert cliente.post(f"/api/excecoes/{excecao_id}/resolver",
                            json={"decisao": "Resolvido em teste"}).status_code == 200

        # Auditoria e dashboard
        assert len(cliente.get("/api/auditoria").get_json()) > 0
        d = cliente.get("/api/dashboard").get_json()
        assert d["materiais_cadastrados"] == 1
        assert d["tarefas_concluidas"] == 1
        assert d["excecoes_abertas"] == 0

        # Persistência
        assert db.buscar_material(material_id)["codigo"] == "MAT-001"

    print("SMOKE TEST PASS")


if __name__ == "__main__":
    main()
