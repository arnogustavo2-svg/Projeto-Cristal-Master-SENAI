# AAI — Almoxarifado Assistido por IA

Sistema de apoio ao controle de almoxarifado e retirada de materiais para
Ordens de Produção (OP). Duas áreas: **Líder** (administra) e **Operador**
(executa).

## OPs operacionais iniciais

Na inicialização, `garantir_ordens_operacionais_iniciais()` garante as OPs
`OP-001` a `OP-010`, com materiais, itens e tarefas de separação. É
idempotente: reiniciar não duplica. Não existe aba nem botão de simulação —
as OPs aparecem em **Ordens de Produção** e as tarefas em **Tarefas** (líder)
e **Minhas tarefas** (operador). A carga não movimenta estoque.

A `OP-001` representa 2.000 kg em 20 misturas de 100,00 kg
(`20x | 100,00 kg`). Não confundir com capacidade de pallet, peso de sacaria
ou saldo de estoque.

## Eventos RFID e horário

Eventos recebidos usam `America/Sao_Paulo` e são devolvidos com o fuso
explícito. A mesma UID não é aceita novamente dentro da janela definida por
`RFID_DUPLICATE_WINDOW_SECONDS` (30 s por padrão). O mesmo `evento_id` é
idempotente. A leitura **não movimenta estoque** — apenas registra e devolve
o contexto da UID cadastrada.

## Stack

Python, Flask, SQLite3, Pydantic, HTML, CSS, JavaScript. Sem Blueprints,
Application Factory, ORM, frameworks JS, WebSocket, Docker ou MQTT.

## Estrutura de pastas

```
.
├── app.py
├── database.py
├── schemas.py
├── run.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── lider/        (dashboard, materiais, estoque, operadores, ordens,
│   │                   ordem-detalhes, tarefas, movimentacoes, auditoria,
│   │                   dispositivos, rfid, excecoes, _sidebar)
│   └── operador/      (acesso, inicio, tarefas, tarefa-detalhes,
│                        confirmacao, excecao)
├── static/
│   ├── css/style.css
│   ├── js/{lider.js, operador.js}
│   └── images/banner_smartcolector.jpg
└── scripts/
    └── smoke_test.py
```

## Instalação

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Execução

```bash
python run.py
# abrir http://127.0.0.1:5000
```

## Testes

```bash
python scripts/smoke_test.py
```

## Regra de permissão

```
Líder administra.
Operador executa.
```

## Configuração da autenticação ESP32

Variáveis em `.env` (nunca commitar):

- `ESP32_DEVICE_TOKEN` — token esperado no cabeçalho `X-Device-Token`.
- `ESP32_DEV_MODE` — `true` permite o endpoint sem token (uso local).
- `RFID_DUPLICATE_WINDOW_SECONDS` — janela contra leitura repetida.
- `FLASK_DEBUG` — `1` liga o modo debug do Flask.

Comportamento fail-closed: sem `ESP32_DEVICE_TOKEN`, o endpoint só aceita em
`ESP32_DEV_MODE=true`. Token ausente ou incorreto → 401. O token nunca aparece
em logs, auditoria, banco ou resposta.

## Rotas HTML

```
GET  /
GET  /lider
GET  /lider/materiais
GET  /lider/estoque
GET  /lider/operadores
GET  /lider/ordens
GET  /lider/ordens/<id>
GET  /lider/tarefas
GET  /lider/movimentacoes
GET  /lider/auditoria
GET  /lider/dispositivos
GET  /lider/rfid
GET  /lider/excecoes
GET  /operador
GET  /operador/inicio
GET  /operador/tarefas
GET  /operador/tarefas/<id>
GET  /operador/confirmacao
GET  /operador/excecao
```

## Rotas API

```
GET  /api/health
GET  /api/materiais                    POST /api/materiais
PUT  /api/materiais/<id>
POST /api/materiais/<id>/ativar        POST /api/materiais/<id>/desativar
GET  /api/operadores                   POST /api/operadores
PUT  /api/operadores/<id>
POST /api/operador/identificar
GET  /api/operador/tarefas?matricula=
POST /api/operador/tarefas/<id>/iniciar
POST /api/operador/tarefas/<id>/concluir
GET  /api/posicoes                     POST /api/posicoes
GET  /api/lotes                        POST /api/lotes
GET  /api/pallets                      POST /api/pallets
POST /api/pallets/<id>/bloquear        POST /api/pallets/<id>/desbloquear
GET  /api/estoque
POST /api/movimentacoes/entrada
GET  /api/movimentacoes
GET  /api/ordens                       POST /api/ordens
GET  /api/ordens/<id>
POST /api/ordens/<id>/gerar-tarefas
POST /api/ordens/<id>/finalizar        POST /api/ordens/<id>/cancelar
GET  /api/tarefas                      GET /api/tarefas/<id>
POST /api/tarefas/<id>/cancelar
GET  /api/excecoes                     POST /api/excecoes
POST /api/excecoes/<id>/resolver
GET  /api/rfid                         POST /api/rfid
GET  /api/rfid/<uid>
POST /api/rfid/<id>/desassociar
GET  /api/dispositivos                 GET /api/dispositivos/eventos
POST /api/dispositivos/eventos
GET  /api/auditoria
GET  /api/dashboard
```

## UID RFID — formato canônico

- Entrada aceita: `04-a7 32:91`, `04A73291`, `04 A7 32 91`.
- Forma armazenada e devolvida: `04-A7-32-91-B2-6C-80`.
- Única por tag ativa.
- A leitura não movimenta estoque. O endpoint devolve o contexto quando a
  UID está cadastrada, ou `status: "nao_cadastrada"` quando não.

## Códigos HTTP

- `200` — OK / evento idempotente
- `201` — criado / evento novo
- `401` — dispositivo não autenticado
- `404` — registro inexistente / UID não cadastrada
- `409` — conflito (duplicidade, pallet bloqueado, saldo insuficiente,
  UID repetida na janela, OP encerrada)
- `422` — dados inválidos
- `500` — erro inesperado (sem traceback)

## Tabelas

`materiais`, `operadores`, `posicoes`, `lotes`, `pallets`,
`ordens_producao`, `itens_ordem_producao`, `tarefas`, `movimentacoes`,
`auditoria`, `eventos_dispositivo`, `excecoes`, `rfid_tags`.

## Fora do escopo desta versão

- Firmware MicroPython do ESP32 (equipe de IoT).
- Integração Gemini para leitura de OPs (retomada futura).
- FEFO (sem regra definida de validade).
- Autenticação de usuários líder/operador (matrícula é provisória).
