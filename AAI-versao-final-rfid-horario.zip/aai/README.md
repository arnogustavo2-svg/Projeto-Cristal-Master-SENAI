# AAI — Almoxarifado Assistido por IA

Sistema de apoio ao controle de almoxarifado e retirada de materiais para
Ordens de Produção (OP). Duas áreas: **Líder** (administra) e **Operador**
(executa).

## OPs operacionais iniciais

Na inicialização, o sistema garante automaticamente as OPs `OP-001` a `OP-010`,
com seus materiais, itens e tarefas de separação. Essa carga é idempotente:
reiniciar o sistema não duplica registros. Não existe aba nem botão de simulação;
as OPs aparecem diretamente em **Ordens de Produção**, as tarefas aparecem no
painel do líder e ficam disponíveis ao operador após sua identificação.

A `OP-001` representa 2.000 kg em 20 misturas de 100,00 kg (`20x | 100,00 kg`).
Essa carga inicial não movimenta estoque; entradas e saídas continuam dependendo
da execução real das tarefas.

## Eventos RFID e horário

Eventos recebidos pelo endpoint de dispositivos usam o horário local de
`America/Sao_Paulo` e são devolvidos à interface com o fuso explícito. A mesma
UID não é aceita novamente dentro da janela de proteção definida por
`RFID_DUPLICATE_WINDOW_SECONDS` (30 segundos por padrão), evitando que uma
etiqueta parada no leitor gere várias leituras. Depois da janela, uma nova
leitura pode ser registrada normalmente. A repetição do mesmo `evento_id` também
continua idempotente.

## Stack

Python, Flask, SQLite3, Pydantic, HTML, CSS, JavaScript. Sem Blueprints,
Application Factory, ORM, frameworks JS ou Docker.

## Estrutura de pastas

```
.
├── app.py
├── database.py
├── schemas.py
├── run.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── lider/        (dashboard, materiais, estoque, operadores, ordens,
│   │                   ordem-detalhes, tarefas, movimentacoes, auditoria,
│   │                   dispositivos, excecoes, _sidebar)
│   └── operador/      (acesso, inicio, tarefas, tarefa-detalhes,
│                        confirmacao, excecao)
├── static/
│   ├── css/style.css
│   ├── js/{lider.js, operador.js}
│   └── images/banner_smartcolector.jpg
└── scripts/
    └── smoke_test.py
```

## Instalação

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Execução

```bash
python run.py
# abrir http://127.0.0.1:5000
```

## Testes

```bash
python scripts/smoke_test.py
```

## Regra de permissão

```
Líder administra.
Operador executa.
```

A OP pertence à área do líder. O operador recebe e executa tarefas geradas
a partir da OP; não cria nem administra OP, material ou operador.

## Rotas HTML

```
GET  /
GET  /lider
GET  /lider/materiais
GET  /lider/estoque
GET  /lider/operadores
GET  /lider/ordens
GET  /lider/ordens/<id>
GET  /lider/tarefas
GET  /lider/movimentacoes
GET  /lider/auditoria
GET  /lider/dispositivos
GET  /lider/excecoes
GET  /operador
GET  /operador/inicio
GET  /operador/tarefas
GET  /operador/tarefas/<id>
GET  /operador/confirmacao
GET  /operador/excecao
```

## Rotas API

```
GET  /api/health
GET  /api/materiais                    POST /api/materiais
PUT  /api/materiais/<id>
POST /api/materiais/<id>/ativar        POST /api/materiais/<id>/desativar
GET  /api/operadores                   POST /api/operadores
PUT  /api/operadores/<id>
POST /api/operador/identificar
GET  /api/operador/tarefas?matricula=
POST /api/operador/tarefas/<id>/iniciar
POST /api/operador/tarefas/<id>/concluir
GET  /api/posicoes                     POST /api/posicoes
GET  /api/lotes                        POST /api/lotes
GET  /api/pallets                      POST /api/pallets
POST /api/pallets/<id>/bloquear        POST /api/pallets/<id>/desbloquear
GET  /api/estoque
POST /api/movimentacoes/entrada
GET  /api/movimentacoes
GET  /api/ordens                       POST /api/ordens
GET  /api/ordens/<id>
POST /api/ordens/<id>/gerar-tarefas
POST /api/ordens/<id>/finalizar        POST /api/ordens/<id>/cancelar
GET  /api/tarefas                      GET /api/tarefas/<id>
POST /api/tarefas/<id>/cancelar
GET  /api/excecoes                     POST /api/excecoes
POST /api/excecoes/<id>/resolver
GET  /api/dispositivos                 GET /api/dispositivos/eventos
POST /api/dispositivos/eventos
GET  /api/auditoria
GET  /api/dashboard
```

## Tabelas

`materiais`, `operadores`, `posicoes`, `lotes`, `pallets`,
`ordens_producao`, `itens_ordem_producao`, `tarefas`, `movimentacoes`,
`auditoria`, `eventos_dispositivo`, `excecoes`.

## Implementado e testado

- CRUD de materiais (com verificação de existência antes de ativar/desativar)
- CRUD de operadores; identificação por matrícula (sem senha)
- Posições, lotes, pallets (com bloqueio/desbloqueio)
- Entrada de estoque e cálculo de saldo por material, lote ou pallet
- Ordens de Produção com itens, prioridade e prazo
- Geração de tarefas a partir da OP, com recomendação FIFO de lote
- Execução de tarefa pelo operador (iniciar/concluir), com:
  - bloqueio de pallet impedindo movimentação
  - validação de saldo suficiente **antes** de gravar a saída (bug de
    cálculo de saldo do rascunho anterior corrigido — a consulta agora
    seleciona explicitamente material, lote ou pallet, nunca combina
    identificadores de forma ambígua)
- Finalização automática da OP quando todas as tarefas são concluídas
- Registro de movimentações (entrada/saída) ligadas a material/lote/pallet
- Registro de exceções pelo operador e resolução pelo líder
- Recebimento idempotente de eventos de dispositivo (ESP/RFID) — duplicidade
  tratada
- Auditoria de ações (criação, alteração, bloqueio, conclusão etc.)
- Dashboard do líder com dados reais do banco, atualizado por polling
  JavaScript a cada 5s (sem WebSocket)

## Implementado parcialmente

- **FIFO**: a recomendação de lote (mais antigo com saldo) está ligada ao
  fluxo real de geração de tarefas e à retirada. Considerado CONFORME.
- **FEFO**: não implementado. A tabela `lotes` guarda `validade`, mas não
  há regra que priorize lote por vencimento. PENDENTE.

## Planejado / fora do escopo desta versão

- Autenticação real (login/senha) do líder — o painel está aberto,
  sem sessão, cookies ou tokens. Ambiente de desenvolvimento apenas.
- Integração elétrica real com ESP32/RFID — a rota recebe e valida JSON;
  nenhum firmware ou GPIO é implementado.
- Relatórios, exportações, impressão.
- WebSocket / tempo real (decisão intencional; polling é suficiente nesta
  fase).

## Exemplos

```bash
curl -X POST http://127.0.0.1:5000/api/materiais \
  -H 'Content-Type: application/json' \
  -d '{"codigo":"MAT-001","descricao":"Resina","unidade":"kg"}'

curl -X POST http://127.0.0.1:5000/api/dispositivos/eventos \
  -H 'Content-Type: application/json' \
  -d '{"evento_id":"EVT-001","dispositivo_id":"ESP32-A1","uid_rfid":"RFID-001","tipo_evento":"tag_detectada","valor":true}'
```

### Integração futura com ESP32

O hardware e o firmware do ESP32 serão produzidos por outra equipe. Este projeto
mantém somente a API real para receber eventos; não há simulador de dispositivos,
eventos artificiais ou horários gerados automaticamente.

O firmware poderá usar, conforme o hardware escolhido:

```cpp
#include <WiFi.h>          // conexão Wi-Fi
#include <HTTPClient.h>    // requisições HTTP para o Flask
#include <ArduinoJson.h>   // montagem e leitura do JSON
#include <MFRC522.h>       // leitor RFID MFRC522, se esse modelo for escolhido
#include <SPI.h>           // interface SPI do leitor, quando aplicável
```

`WiFi.h`, `HTTPClient.h` e `ArduinoJson.h` pertencem ao firmware C/C++ do
ESP32, não ao servidor Python. `MFRC522.h` é específica do leitor RFID; caso a
outra equipe use PN532, a biblioteca será diferente. `SPI.h` ou `Wire.h` também
dependerão da interface elétrica escolhida. Para HTTPS pode ser necessário
`WiFiClientSecure.h`; para guardar configuração local, `Preferences.h`.

O evento futuro deverá possuir um `evento_id` único e persistente, permitindo
reenvio seguro após queda de Wi-Fi:

```json
{
  "evento_id": "ESP32-A1-000001",
  "dispositivo_id": "ESP32-A1",
  "baia": "BAIA-A",
  "uid_rfid": "RFID-001",
  "tipo_evento": "tag_detectada",
  "valor": true
}
```

O endpoint registra o evento na tela **Líder → Dispositivos**. A página atualiza
ao abrir, pelo botão **Atualizar** e por polling de cinco segundos. Receber um
evento não altera automaticamente OP, tarefa ou estoque; qualquer vínculo futuro
deverá validar dispositivo, UID, pallet, baia, tarefa e status operacional.
